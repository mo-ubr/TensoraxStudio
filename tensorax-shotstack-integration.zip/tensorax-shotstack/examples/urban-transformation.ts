// ============================================================
// TensoraxStudio — Example: Urban Transformation Video
//
// This demonstrates the full pipeline:
//   1. Nano Banana generates keyframe images
//   2. Kling turns keyframes into video segments
//   3. ElevenLabs generates voiceover
//   4. Shotstack composites everything into a final MP4
// ============================================================

import { TensoraxCompositor, loadShotstackConfig } from '../src/index.js';
import type { TensoraxAsset, CompositionConfig } from '../src/index.js';

async function main() {
  // --- Load config from environment ---
  const config = loadShotstackConfig();
  const compositor = new TensoraxCompositor(config);

  // --- Define pipeline assets ---
  // In production these URLs come from your Nano Banana, Kling,
  // and ElevenLabs service responses.

  const assets: TensoraxAsset[] = [
    // Keyframe 1 — "before" shot (Nano Banana)
    {
      id: 'kf-001',
      type: 'keyframe',
      source: 'nano_banana',
      url: 'https://your-storage.com/assets/keyframe-before.png',
      duration: 3,
    },

    // Video segment 1 — transformation sequence (Kling)
    {
      id: 'vs-001',
      type: 'video_segment',
      source: 'kling',
      url: 'https://your-storage.com/assets/transform-segment-01.mp4',
      duration: 8,
    },

    // Video segment 2 — aerial flyover (Kling)
    {
      id: 'vs-002',
      type: 'video_segment',
      source: 'kling',
      url: 'https://your-storage.com/assets/aerial-flyover-01.mp4',
      duration: 6,
    },

    // Keyframe 2 — "after" hero shot (Nano Banana)
    {
      id: 'kf-002',
      type: 'keyframe',
      source: 'nano_banana',
      url: 'https://your-storage.com/assets/keyframe-after.png',
      duration: 4,
    },

    // Voiceover (ElevenLabs)
    {
      id: 'vo-001',
      type: 'voiceover',
      source: 'elevenlabs',
      url: 'https://your-storage.com/assets/voiceover-en.mp3',
      duration: 20,
      startAt: 0,
    },

    // Background music
    {
      id: 'bgm-001',
      type: 'music',
      source: 'local',
      url: 'https://your-storage.com/assets/ambient-track.mp3',
    },
  ];

  // --- Composition settings ---
  const compositionConfig: CompositionConfig = {
    output: {
      format: 'mp4',
      resolution: '1080',
      aspectRatio: '16:9',
      fps: 25,
      quality: 'high',
    },
    background: '#000000',
    brandingOverlay: 'https://your-storage.com/assets/ubr-watermark.png',
    segmentTransition: 'fade',
    keyframeHoldDuration: 4,
    callbackUrl: 'https://your-server.com/api/webhooks/shotstack',
  };

  // --- Option A: Fire-and-forget (use with webhooks) ---
  console.log('Queuing composition...');
  const { renderId } = await compositor.composeAsync(assets, compositionConfig);
  console.log(`Queued! Render ID: ${renderId}`);
  console.log('Webhook will fire when complete.');

  // --- Option B: Wait for result (blocking) ---
  // Uncomment below instead of Option A if you prefer polling:
  //
  // console.log('Composing video (this will poll until done)...');
  // const result = await compositor.compose(assets, compositionConfig);
  //
  // if (result.status === 'done') {
  //   console.log(`Video ready: ${result.url}`);
  // } else {
  //   console.error(`Render failed: ${result.status}`);
  // }
}

main().catch(console.error);
