// ============================================================
// TensoraxStudio — Shotstack Config Loader
// Reads SHOTSTACK_API_KEY and SHOTSTACK_ENV from environment.
// ============================================================

import type { ShotstackConfig, ShotstackEnvironment } from '../types/shotstack.types.js';

export function loadShotstackConfig(): ShotstackConfig {
  const apiKey = process.env.SHOTSTACK_API_KEY;

  if (!apiKey) {
    throw new Error(
      'SHOTSTACK_API_KEY is not set. ' +
      'Get your key from https://dashboard.shotstack.io and add it to .env'
    );
  }

  const env = (process.env.SHOTSTACK_ENV ?? 'v1') as ShotstackEnvironment;

  if (!['v1', 'stage'].includes(env)) {
    throw new Error(
      `Invalid SHOTSTACK_ENV "${env}". Must be "v1" (production) or "stage" (sandbox).`
    );
  }

  return {
    apiKey,
    environment: env,
    callbackUrl: process.env.SHOTSTACK_CALLBACK_URL,
  };
}
