// ============================================================
// TensoraxStudio — Shotstack API Service
// Low-level wrapper around the Shotstack REST API.
// ============================================================

import type {
  ShotstackConfig,
  Edit,
  QueuedResponse,
  RenderResponse,
  RenderStatus,
  Template,
  TemplateRender,
} from '../types/shotstack.types.js';

const DEFAULT_POLL_INTERVAL_MS = 3_000;
const DEFAULT_POLL_TIMEOUT_MS = 300_000; // 5 min

export class ShotstackService {
  private apiKey: string;
  private baseUrl: string;
  private serveUrl: string;
  private ingestUrl: string;

  constructor(config: ShotstackConfig) {
    this.apiKey = config.apiKey;
    const env = config.environment ?? 'v1';
    this.baseUrl = `https://api.shotstack.io/edit/${env}`;
    this.serveUrl = `https://api.shotstack.io/serve/${env}`;
    this.ingestUrl = `https://api.shotstack.io/ingest/${env}`;
  }

  // ----------------------------------------------------------
  // Internal fetch helper
  // ----------------------------------------------------------

  private async request<T>(
    url: string,
    options: RequestInit = {}
  ): Promise<T> {
    const res = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'x-api-key': this.apiKey,
        ...(options.headers as Record<string, string> ?? {}),
      },
    });

    if (!res.ok) {
      const body = await res.text();
      throw new Error(
        `Shotstack API error ${res.status}: ${body}`
      );
    }

    return res.json() as Promise<T>;
  }

  // ----------------------------------------------------------
  // Edit API
  // ----------------------------------------------------------

  /** Queue a render job and return the render ID. */
  async render(edit: Edit): Promise<QueuedResponse> {
    return this.request<QueuedResponse>(
      `${this.baseUrl}/render`,
      { method: 'POST', body: JSON.stringify(edit) }
    );
  }

  /** Check the status of a render by ID. */
  async getRenderStatus(renderId: string): Promise<RenderResponse> {
    return this.request<RenderResponse>(
      `${this.baseUrl}/render/${renderId}`
    );
  }

  /**
   * Poll until the render reaches a terminal state ('done' | 'failed').
   * Returns the final RenderResponse.
   */
  async waitForRender(
    renderId: string,
    pollIntervalMs = DEFAULT_POLL_INTERVAL_MS,
    timeoutMs = DEFAULT_POLL_TIMEOUT_MS
  ): Promise<RenderResponse> {
    const start = Date.now();
    const terminalStates: RenderStatus[] = ['done', 'failed'];

    while (Date.now() - start < timeoutMs) {
      const res = await this.getRenderStatus(renderId);
      const status = res.response.status;

      console.log(
        `[Shotstack] Render ${renderId} — ${status} (${Math.round((Date.now() - start) / 1000)}s)`
      );

      if (terminalStates.includes(status)) return res;

      await this.sleep(pollIntervalMs);
    }

    throw new Error(
      `Shotstack render ${renderId} timed out after ${timeoutMs / 1000}s`
    );
  }

  /**
   * Convenience: render + poll until done, return the final response.
   */
  async renderAndWait(edit: Edit): Promise<RenderResponse> {
    const queued = await this.render(edit);
    const renderId = queued.response.id;
    console.log(`[Shotstack] Queued render: ${renderId}`);
    return this.waitForRender(renderId);
  }

  // ----------------------------------------------------------
  // Templates
  // ----------------------------------------------------------

  async createTemplate(template: Template): Promise<{ id: string }> {
    const res = await this.request<{
      success: boolean;
      response: { message: string; id: string };
    }>(`${this.baseUrl}/templates`, {
      method: 'POST',
      body: JSON.stringify(template),
    });
    return { id: res.response.id };
  }

  async renderTemplate(render: TemplateRender): Promise<QueuedResponse> {
    return this.request<QueuedResponse>(
      `${this.baseUrl}/templates/render`,
      { method: 'POST', body: JSON.stringify(render) }
    );
  }

  // ----------------------------------------------------------
  // Ingest API — upload source assets
  // ----------------------------------------------------------

  async ingestFromUrl(
    url: string,
    options?: { format?: string; callback?: string }
  ): Promise<{ id: string }> {
    const body: Record<string, unknown> = { url };
    if (options?.callback) body.callback = options.callback;
    if (options?.format) {
      body.outputs = {
        renditions: [{ format: options.format }],
      };
    }

    const res = await this.request<{
      data: { id: string };
    }>(`${this.ingestUrl}/sources`, {
      method: 'POST',
      body: JSON.stringify(body),
    });

    return { id: res.data.id };
  }

  // ----------------------------------------------------------
  // Serve API — hosted asset management
  // ----------------------------------------------------------

  async getAssetsByRenderId(renderId: string): Promise<unknown[]> {
    const res = await this.request<{ data: unknown[] }>(
      `${this.serveUrl}/assets/render/${renderId}`
    );
    return res.data;
  }

  async deleteAsset(assetId: string): Promise<void> {
    await this.request(`${this.serveUrl}/assets/${assetId}`, {
      method: 'DELETE',
    });
  }

  // ----------------------------------------------------------
  // Inspect (probe) a media file
  // ----------------------------------------------------------

  async probe(url: string): Promise<{
    metadata: Record<string, unknown>;
    streams: unknown[];
  }> {
    const res = await this.request<{
      response: { metadata: Record<string, unknown>; streams: unknown[] };
    }>(`${this.baseUrl}/probe/${encodeURIComponent(url)}`);
    return res.response;
  }

  // ----------------------------------------------------------
  // Helpers
  // ----------------------------------------------------------

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
