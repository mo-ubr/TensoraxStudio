// ============================================================
// TensoraxStudio — Pipeline Compositor
//
// Takes assets produced by the TensoraxStudio pipeline stages
// (Nano Banana keyframes, Kling/Veo video segments, ElevenLabs
// voiceover) and assembles them into a Shotstack Edit for
// final rendering.
// ============================================================

import { ShotstackService } from './shotstack.service.js';
import type {
  ShotstackConfig,
  TensoraxAsset,
  CompositionConfig,
  CompositionResult,
  Edit,
  Timeline,
  Track,
  Clip,
  OutputConfig,
  TransitionEffect,
  RenderResponse,
} from '../types/shotstack.types.js';

const DEFAULTS: Required<
  Pick<
    CompositionConfig,
    'background' | 'segmentTransition' | 'keyframeHoldDuration'
  >
> = {
  background: '#000000',
  segmentTransition: 'fade',
  keyframeHoldDuration: 4,
};

export class TensoraxCompositor {
  private shotstack: ShotstackService;

  constructor(config: ShotstackConfig) {
    this.shotstack = new ShotstackService(config);
  }

  // ----------------------------------------------------------
  // Public API
  // ----------------------------------------------------------

  /**
   * Compose a finished video from TensoraxStudio pipeline assets.
   *
   * Asset ordering:
   *   - If an asset has `startAt`, it's placed at that exact second.
   *   - Otherwise assets of the same type are laid out sequentially
   *     in the order provided.
   *
   * Layering (top → bottom):
   *   Track 0  — Branding overlay (optional)
   *   Track 1  — Text / captions
   *   Track 2  — Video segments & keyframe stills
   *   Track 3  — Voiceover audio
   *   Soundtrack — Background music (if supplied)
   */
  async compose(
    assets: TensoraxAsset[],
    config: CompositionConfig
  ): Promise<CompositionResult> {
    const edit = this.buildEdit(assets, config);
    const response = await this.shotstack.renderAndWait(edit);
    return this.mapResult(response);
  }

  /**
   * Same as compose() but returns immediately with the render ID
   * so you can poll or use webhooks.
   */
  async composeAsync(
    assets: TensoraxAsset[],
    config: CompositionConfig
  ): Promise<{ renderId: string }> {
    const edit = this.buildEdit(assets, config);
    const queued = await this.shotstack.render(edit);
    return { renderId: queued.response.id };
  }

  /** Check status of a previously queued composition. */
  async getStatus(renderId: string): Promise<CompositionResult> {
    const response = await this.shotstack.getRenderStatus(renderId);
    return this.mapResult(response);
  }

  /** Probe a remote media file to get duration/metadata. */
  async probeAsset(url: string) {
    return this.shotstack.probe(url);
  }

  // ----------------------------------------------------------
  // Edit builder
  // ----------------------------------------------------------

  private buildEdit(
    assets: TensoraxAsset[],
    config: CompositionConfig
  ): Edit {
    const bg = config.background ?? DEFAULTS.background;
    const transition = config.segmentTransition ?? DEFAULTS.segmentTransition;
    const holdDuration =
      config.keyframeHoldDuration ?? DEFAULTS.keyframeHoldDuration;

    // Partition assets by role
    const videoSegments = assets.filter((a) => a.type === 'video_segment');
    const keyframes = assets.filter((a) => a.type === 'keyframe');
    const voiceovers = assets.filter((a) => a.type === 'voiceover');
    const music = assets.filter((a) => a.type === 'music');
    const subtitles = assets.filter((a) => a.type === 'subtitle');

    // Build the visual track (video segments + keyframe stills)
    const visualClips = this.buildVisualClips(
      videoSegments,
      keyframes,
      holdDuration,
      transition
    );

    // Build audio track (voiceover)
    const audioClips = this.buildAudioClips(voiceovers);

    // Build caption track
    const captionClips = this.buildCaptionClips(subtitles);

    // Assemble tracks — higher index = lower layer
    const tracks: Track[] = [];

    // Branding overlay (top layer)
    if (config.brandingOverlay) {
      const totalDuration = this.totalDuration(visualClips);
      tracks.push({
        clips: [
          {
            asset: { type: 'image', src: config.brandingOverlay },
            start: 0,
            length: totalDuration,
            fit: 'none',
            scale: 0.15,
            position: 'topRight',
            offset: { x: -0.03, y: -0.03 },
            opacity: 0.7,
          },
        ],
      });
    }

    // Captions
    if (captionClips.length > 0) {
      tracks.push({ clips: captionClips });
    }

    // Visuals
    if (visualClips.length > 0) {
      tracks.push({ clips: visualClips });
    }

    // Audio
    if (audioClips.length > 0) {
      tracks.push({ clips: audioClips });
    }

    const timeline: Timeline = {
      background: bg,
      tracks,
      cache: true,
    };

    // Background music → soundtrack
    if (music.length > 0) {
      timeline.soundtrack = {
        src: music[0].url,
        effect: 'fadeInFadeOut',
        volume: 0.3,
      };
    }

    const edit: Edit = {
      timeline,
      output: config.output,
    };

    if (config.callbackUrl) {
      edit.callback = config.callbackUrl;
    }

    return edit;
  }

  // ----------------------------------------------------------
  // Clip builders
  // ----------------------------------------------------------

  private buildVisualClips(
    videoSegments: TensoraxAsset[],
    keyframes: TensoraxAsset[],
    holdDuration: number,
    transition: TransitionEffect
  ): Clip[] {
    const clips: Clip[] = [];
    let cursor = 0; // current timeline position in seconds

    // Interleave: if a video segment exists for a position, use it.
    // Otherwise fall back to a keyframe still held for `holdDuration`.
    // Assets with explicit `startAt` are placed absolutely.

    // First pass: explicit-position assets
    const explicit = [...videoSegments, ...keyframes].filter(
      (a) => a.startAt !== undefined
    );
    const sequential = [...videoSegments, ...keyframes]
      .filter((a) => a.startAt === undefined)
      .sort((a, b) => {
        // video_segment before keyframe at same position
        if (a.type !== b.type) return a.type === 'video_segment' ? -1 : 1;
        return 0;
      });

    // Place sequential assets first
    for (const asset of sequential) {
      const clip = this.assetToVisualClip(asset, cursor, holdDuration, transition);
      clips.push(clip);
      cursor += clip.length;
    }

    // Place explicit-position assets (these overlay or fill gaps)
    for (const asset of explicit) {
      const clip = this.assetToVisualClip(
        asset,
        asset.startAt!,
        holdDuration,
        transition
      );
      clips.push(clip);
    }

    return clips;
  }

  private assetToVisualClip(
    asset: TensoraxAsset,
    start: number,
    holdDuration: number,
    transition: TransitionEffect
  ): Clip {
    if (asset.type === 'video_segment') {
      return {
        asset: {
          type: 'video',
          src: asset.url,
          volume: 0, // mute segment audio — voiceover is separate
        },
        start,
        length: asset.duration ?? 5,
        fit: 'cover',
        transition: { in: transition, out: 'none' },
      };
    }

    // Keyframe (image) — hold for configured duration
    return {
      asset: { type: 'image', src: asset.url },
      start,
      length: asset.duration ?? holdDuration,
      fit: 'cover',
      effect: 'zoomIn',
      transition: { in: transition, out: 'none' },
    };
  }

  private buildAudioClips(voiceovers: TensoraxAsset[]): Clip[] {
    const clips: Clip[] = [];
    let cursor = 0;

    for (const vo of voiceovers) {
      const start = vo.startAt ?? cursor;
      const length = vo.duration ?? 10;
      clips.push({
        asset: {
          type: 'audio',
          src: vo.url,
          effect: 'fadeInFadeOut',
        },
        start,
        length,
      });
      cursor = start + length;
    }

    return clips;
  }

  private buildCaptionClips(subtitles: TensoraxAsset[]): Clip[] {
    return subtitles.map((sub) => ({
      asset: {
        type: 'caption' as const,
        src: sub.url,
        // Font/style can be extended via sub.metadata
      },
      start: sub.startAt ?? 0,
      length: sub.duration ?? 10,
      position: 'bottom' as const,
    }));
  }

  // ----------------------------------------------------------
  // Utilities
  // ----------------------------------------------------------

  private totalDuration(clips: Clip[]): number {
    if (clips.length === 0) return 0;
    return Math.max(...clips.map((c) => c.start + c.length));
  }

  private mapResult(response: RenderResponse): CompositionResult {
    return {
      renderId: response.response.id,
      status: response.response.status,
      url: response.response.url,
    };
  }
}
