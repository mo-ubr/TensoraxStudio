// ============================================================
// TensoraxStudio — Shotstack Integration Types
// ============================================================

// --- Core Shotstack API types ---

export type ShotstackEnvironment = 'v1' | 'stage';

export interface ShotstackConfig {
  apiKey: string;
  environment: ShotstackEnvironment;
  callbackUrl?: string;
}

export interface VideoAsset {
  type: 'video';
  src: string;
  trim?: number;
  volume?: number;
  volumeEffect?: 'fadeIn' | 'fadeOut' | 'fadeInFadeOut' | 'none';
  speed?: number;
  crop?: Crop;
  chromaKey?: ChromaKey;
}

export interface ImageAsset {
  type: 'image';
  src: string;
  crop?: Crop;
}

export interface AudioAsset {
  type: 'audio';
  src: string;
  trim?: number;
  volume?: number;
  speed?: number;
  effect?: 'fadeIn' | 'fadeOut' | 'fadeInFadeOut';
}

export interface TextAsset {
  type: 'text';
  text: string;
  font?: TextFont;
  alignment?: TextAlignment;
  background?: string;
  color?: string;
  size?: 'xx-small' | 'x-small' | 'small' | 'medium' | 'large' | 'x-large' | 'xx-large';
  style?: 'italic';
  weight?: number;
}

export interface HtmlAsset {
  type: 'html';
  html: string;
  css?: string;
  width?: number;
  height?: number;
}

export interface CaptionAsset {
  type: 'caption';
  src: string;
  font?: CaptionFont;
  background?: string;
  color?: string;
}

export type ClipAsset = VideoAsset | ImageAsset | AudioAsset | TextAsset | HtmlAsset | CaptionAsset;

export interface Crop {
  top?: number;
  bottom?: number;
  left?: number;
  right?: number;
}

export interface ChromaKey {
  color: string;
  threshold?: number;
  halo?: number;
}

export interface TextFont {
  family?: string;
  color?: string;
  size?: number;
  weight?: number;
}

export interface TextAlignment {
  horizontal?: 'left' | 'center' | 'right';
  vertical?: 'top' | 'center' | 'bottom';
}

export interface CaptionFont {
  family?: string;
  color?: string;
  size?: number;
}

export interface Transition {
  in?: TransitionEffect;
  out?: TransitionEffect;
}

export type TransitionEffect =
  | 'fade' | 'reveal' | 'wipeLeft' | 'wipeRight' | 'wipeUp' | 'wipeDown'
  | 'slideLeft' | 'slideRight' | 'slideUp' | 'slideDown'
  | 'carouselLeft' | 'carouselRight' | 'carouselUp' | 'carouselDown'
  | 'shuffleTopRight' | 'shuffleRightTop' | 'shuffleRightBottom' | 'shuffleBottomRight'
  | 'shuffleBottomLeft' | 'shuffleLeftBottom' | 'shuffleLeftTop' | 'shuffleTopLeft'
  | 'zoom' | 'none';

export interface Offset {
  x?: number;
  y?: number;
}

export interface Clip {
  asset: ClipAsset;
  start: number;
  length: number;
  fit?: 'cover' | 'contain' | 'crop' | 'none';
  scale?: number;
  width?: number;
  height?: number;
  position?: 'top' | 'topRight' | 'right' | 'bottomRight' | 'bottom' | 'bottomLeft' | 'left' | 'topLeft' | 'center';
  offset?: Offset;
  transition?: Transition;
  effect?: 'zoomIn' | 'zoomOut' | 'slideLeft' | 'slideRight' | 'slideUp' | 'slideDown' | 'none';
  filter?: 'boost' | 'contrast' | 'darken' | 'greyscale' | 'lighten' | 'muted' | 'negative' | 'none';
  opacity?: number;
  transform?: Transform;
}

export interface Transform {
  rotate?: { angle: number };
  skew?: { x: number; y: number };
  flip?: { horizontal?: boolean; vertical?: boolean };
}

export interface Track {
  clips: Clip[];
}

export interface Soundtrack {
  src: string;
  effect?: 'fadeIn' | 'fadeOut' | 'fadeInFadeOut';
  volume?: number;
}

export interface Timeline {
  soundtrack?: Soundtrack;
  background?: string;
  tracks: Track[];
  cache?: boolean;
}

export interface OutputConfig {
  format: 'mp4' | 'gif' | 'mp3' | 'jpg' | 'png' | 'bmp' | 'webm';
  resolution?: 'preview' | 'mobile' | 'sd' | 'hd' | '1080' | '4k';
  aspectRatio?: '16:9' | '9:16' | '1:1' | '4:5' | '4:3';
  size?: { width: number; height: number };
  fps?: number;
  quality?: 'low' | 'medium' | 'high';
  mute?: boolean;
  poster?: { capture: number };
  thumbnail?: { capture: number; scale: number };
}

export interface MergeField {
  find: string;
  replace: string;
}

export interface Edit {
  timeline: Timeline;
  output: OutputConfig;
  merge?: MergeField[];
  callback?: string;
  disk?: 'local' | 'mount';
}

// --- Render responses ---

export interface QueuedResponse {
  success: boolean;
  message: string;
  response: {
    message: string;
    id: string;
  };
}

export type RenderStatus = 'queued' | 'fetching' | 'rendering' | 'saving' | 'done' | 'failed';

export interface RenderResponse {
  success: boolean;
  message: string;
  response: {
    status: RenderStatus;
    id: string;
    owner: string;
    url?: string;
    data?: Edit;
    created: string;
    updated: string;
  };
}

// --- Template types ---

export interface Template {
  name: string;
  template: Edit;
}

export interface TemplateRender {
  id: string;
  merge?: MergeField[];
}

// --- TensoraxStudio Pipeline types ---

export interface TensoraxAsset {
  id: string;
  type: 'keyframe' | 'video_segment' | 'voiceover' | 'music' | 'subtitle';
  source: 'nano_banana' | 'kling' | 'veo' | 'elevenlabs' | 'local';
  url: string;
  duration?: number;       // seconds
  startAt?: number;        // seconds — position in final timeline
  metadata?: Record<string, unknown>;
}

export interface CompositionConfig {
  /** Final output format */
  output: OutputConfig;
  /** Background colour (hex) */
  background?: string;
  /** Branding overlay image URL (e.g. UBR watermark) */
  brandingOverlay?: string;
  /** Transition between video segments */
  segmentTransition?: TransitionEffect;
  /** Duration (seconds) each keyframe image is shown if no video segment */
  keyframeHoldDuration?: number;
  /** Auto-add captions from voiceover transcription */
  autoCaptions?: boolean;
  /** Callback URL for render completion webhook */
  callbackUrl?: string;
}

export interface CompositionResult {
  renderId: string;
  status: RenderStatus;
  url?: string;
  thumbnailUrl?: string;
  posterUrl?: string;
}
