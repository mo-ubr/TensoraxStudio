# Shotstack Integration — CLAUDE.md Context

## What this is

The Shotstack integration is the **final composition stage** of the TensoraxStudio pipeline. It takes assets produced by earlier stages and assembles them into a finished video.

## Pipeline position

```
Claude (creative direction)
  → Nano Banana (keyframe image generation)
  → Kling / Veo (video segment generation from keyframes)
  → ElevenLabs (voiceover generation)
  → **Shotstack (final composition & rendering)** ← this module
```

## Architecture

```
src/
  types/shotstack.types.ts    — All TypeScript interfaces
  services/
    shotstack.service.ts      — Low-level Shotstack REST API wrapper
    compositor.service.ts     — High-level pipeline compositor
  utils/
    config.ts                 — Env-based config loader
  index.ts                    — Barrel exports
```

## Key classes

- **`ShotstackService`** — Direct API wrapper. Use for low-level control: render, poll, templates, ingest, probe.
- **`TensoraxCompositor`** — Pipeline-aware compositor. Takes `TensoraxAsset[]` and `CompositionConfig`, builds a Shotstack timeline with correct layering, and renders.

## Track layering convention (top → bottom)

| Track | Content |
|-------|---------|
| 0 | Branding overlay (UBR watermark) |
| 1 | Captions / subtitles |
| 2 | Video segments + keyframe stills |
| 3 | Voiceover audio |
| Soundtrack | Background music |

## Environment variables

- `SHOTSTACK_API_KEY` — Required. Production key from dashboard.shotstack.io
- `SHOTSTACK_ENV` — `v1` (production) or `stage` (sandbox). Default: `v1`
- `SHOTSTACK_CALLBACK_URL` — Optional webhook for render completion

## MCP Server (for Claude Code)

Add to Claude Code with:
```bash
claude mcp add shotstack -- npx -y @shotstack/shotstack-mcp-server
```
Then set `SHOTSTACK_API_KEY` in your environment. This lets Claude Code generate Shotstack edits via natural language.

## Usage patterns

### Async (webhook-based, preferred for production)
```ts
const { renderId } = await compositor.composeAsync(assets, config);
// Webhook fires at config.callbackUrl when done
```

### Blocking (poll until done)
```ts
const result = await compositor.compose(assets, config);
console.log(result.url); // final video URL
```

## Notes

- Shotstack MCP server requires production keys only (not stage/sandbox)
- Free tier is non-expiring — good for prototyping
- Render times vary: ~30s for short clips, several minutes for 1080p+ long-form
- All rendered assets are hosted on Shotstack CDN by default
